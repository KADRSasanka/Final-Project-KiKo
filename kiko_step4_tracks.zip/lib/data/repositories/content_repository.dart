import 'dart:convert';

import 'package:flutter/services.dart' show rootBundle;

import '../models/level.dart';

/// Loads level lists from assets/content/{trackId}.json
class ContentRepository {
  Future<List<Level>> loadLevels(String trackId) async {
    final raw = await rootBundle.loadString('assets/content/$trackId.json');
    final data = jsonDecode(raw) as Map<String, dynamic>;
    final list = data['levels'] as List;
    return [
      for (var i = 0; i < list.length; i++)
        Level.fromJson(trackId, i, list[i] as Map<String, dynamic>),
    ];
  }
}
